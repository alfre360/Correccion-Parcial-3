package com.example;

public class ConjuntoDeDatosTabular extends ConjuntoDeDatos{

    // Atributos
    private int numeroDeColumnas;
    private int numeroDeFilas;

    // Constructor
    public ConjuntoDeDatosTabular(String nombre, int tamano, int numeroDeColumnas, int numeroDeFilas) {
        super(nombre, tamano);
        this.numeroDeColumnas = numeroDeColumnas;
        this.numeroDeFilas = numeroDeFilas;
    }

    // Getters y Setters
    public int getNumeroDeColumnas() {
        return numeroDeColumnas;
    }

    public void setNumeroDeColumnas(int numeroDeColumnas) {
        this.numeroDeColumnas = numeroDeColumnas;
    }

    public int getNumeroDeFilas() {
        return numeroDeFilas;
    }

    public void setNumeroDeFilas(int numeroDeFilas) {
        this.numeroDeFilas = numeroDeFilas;
    }

    //Sobreescribir el metodo describir
    @Override
    public String describir() {
        String cadena ="";
        cadena+="Nombre: "+getNombre()+"\n";
        cadena+="Tamaño: "+getTamano()+"\n";
        cadena+="Tipo: Tabular"+"\n";
        cadena+="Filas: "+getNumeroDeFilas()+"\n";
        cadena+="Columnas: "+getNumeroDeColumnas()+"\n";
        return cadena;
    }


    

    

    
    
}
