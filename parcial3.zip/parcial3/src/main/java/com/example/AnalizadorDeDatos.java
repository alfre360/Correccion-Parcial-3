package com.example;

import java.util.ArrayList;

public class AnalizadorDeDatos {
    
    // Atributos
    private ArrayList<ConjuntoDeDatos> conjuntoDeDatos;

    // Constructor
    public AnalizadorDeDatos() {
        this.conjuntoDeDatos = new ArrayList<>();
    }

    // Getters y Setters
    public ArrayList<ConjuntoDeDatos> getConjuntoDeDatos() {
        return conjuntoDeDatos;
    }

    public void setConjuntoDeDatos(ArrayList<ConjuntoDeDatos> conjuntoDeDatos) {
        this.conjuntoDeDatos = conjuntoDeDatos;
    }

    // Metodos

    //Agregar un conjunto de datos
    public void agregarConjuntoDeDatos(ConjuntoDeDatos conjuntoDeDatos){
        this.conjuntoDeDatos.add(conjuntoDeDatos);
    }

    //Buscar un conjunto de datos
    public ConjuntoDeDatos buscarConjuntoDeDatos(String nombre)
    {
        for (ConjuntoDeDatos conjuntoDeDatos : this.conjuntoDeDatos) {
            if (conjuntoDeDatos.getNombre().equalsIgnoreCase(nombre)) {
                return conjuntoDeDatos;
            }
        }
        return null;
    }

    //Eliminar un conjunto de datos
    public boolean eliminarConjuntoDeDatos(String nombre)
    {
        ConjuntoDeDatos conjuntoDeDatos = buscarConjuntoDeDatos(nombre);
        if (conjuntoDeDatos != null) {
            this.conjuntoDeDatos.remove(conjuntoDeDatos);
            return true;
        }
        return false;
    }

    //Describur conjunto de datos
    public ArrayList<String> describirConjuntoDeDatos()
    {
        ArrayList<String> lista = new ArrayList<>();
        for (ConjuntoDeDatos conjuntoDeDatos : this.conjuntoDeDatos) {
            lista.add(conjuntoDeDatos.describir());
        }
        return lista;
    }
}
