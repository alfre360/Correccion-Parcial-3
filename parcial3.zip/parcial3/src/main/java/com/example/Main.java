package com.example;

/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args )
    {
        //Crear analizador de datos
        AnalizadorDeDatos analizador = new AnalizadorDeDatos();
        
        //Crear conjuntos de datos
        ConjuntoDeDatosTabular t1 = new ConjuntoDeDatosTabular("Datos de estudiantes", 1000, 5, 200);
        ConjuntoDeDatosImagen i1 = new ConjuntoDeDatosImagen("Imágenes de satélite", 2000, 1080, 720);
        ConjuntoDeDatosImagen i2 = new ConjuntoDeDatosImagen("Imágenes de satélite", 2000, 1080, 720);

        //Agregar conjuntos de datos
        analizador.agregarConjuntoDeDatos(t1);
        analizador.agregarConjuntoDeDatos(i1);
        analizador.agregarConjuntoDeDatos(i2);

        //Describir conjuntos de datos
        System.out.println("Descripción de los conjuntos de datos");
        System.out.println("-------------------------------------");
        for (String descripcion : analizador.describirConjuntoDeDatos()) {
            System.out.println(descripcion);
            System.out.println("-------------------------------------");
        }
        



    }
}
