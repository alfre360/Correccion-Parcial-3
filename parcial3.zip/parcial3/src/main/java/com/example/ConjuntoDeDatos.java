package com.example;

public abstract class ConjuntoDeDatos {
    
    // Atributos
    private String nombre;
    private int tamano;

    // Constructor
    public ConjuntoDeDatos(String nombre, int tamano) {
        this.nombre = nombre;
        this.tamano = tamano;
    }

    //Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTamano() {
        return tamano;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }

    // Metodos
    abstract public String describir();

}
