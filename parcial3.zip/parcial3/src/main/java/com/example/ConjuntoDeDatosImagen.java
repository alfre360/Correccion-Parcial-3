package com.example;

public class ConjuntoDeDatosImagen extends ConjuntoDeDatos {

    //Atributos
    private int ancho;
    private int alto;

    //Constructor
    public ConjuntoDeDatosImagen(String nombre, int tamano, int ancho, int alto) {
        super(nombre, tamano);
        this.ancho = ancho;
        this.alto = alto;
    }
    
    //Getters y Setters
    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int getAlto() {
        return alto;
    }

    public void setAlto(int alto) {
        this.alto = alto;
    }

    
    //Metodos
    //Sobreescribir el metodo describir
    @Override
    public String describir() {
        String cadena ="";
        cadena+="Nombre: "+getNombre()+"\n";
        cadena+="Tamaño: "+getTamano()+"\n";
        cadena+="Tipo: Imagen"+"\n";
        cadena+="Ancho: "+getAncho()+"\n";
        cadena+="Alto: "+getAlto()+"\n";
        return cadena;
    }
    

    

    
    
}
